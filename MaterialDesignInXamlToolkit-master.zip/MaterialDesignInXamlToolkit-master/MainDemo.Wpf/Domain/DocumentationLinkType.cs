﻿namespace MaterialDesignColors.WpfExample.Domain
{
    public enum DocumentationLinkType
    {
        Wiki,
        DemoPageSource,
        ControlSource,
        StyleSource,
        Video
    }
}